//
//  main.m
//  AAA
//
//  Created by MingzhaoChen on 11/24/17.
//  Copyright © 2017 MingzhaoChen. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
