//
//  result.h
//  AAA
//
//  Created by MingzhaoChen on 11/26/17.
//  Copyright © 2017 MingzhaoChen. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface result : NSViewController
@property (weak) IBOutlet NSTextField *text;

@property (weak) IBOutlet NSTextField *schema;

@end
